<?php

return [
    'name' => 'Menu'
];
