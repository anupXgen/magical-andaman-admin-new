<?php

return [
    'name' => 'Enquiry',
];
