<?php

return [
    'name' => 'PnrStatus',
];
