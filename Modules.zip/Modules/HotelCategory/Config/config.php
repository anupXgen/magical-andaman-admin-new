<?php

return [
    'name' => 'HotelCategory',
];
