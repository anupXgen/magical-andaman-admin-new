<?php

return [
    'name' => 'Banner',
];
