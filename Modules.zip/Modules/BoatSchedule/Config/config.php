<?php

return [
    'name' => 'BoatSchedule',
];
