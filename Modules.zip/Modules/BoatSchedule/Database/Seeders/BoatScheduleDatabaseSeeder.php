<?php

namespace Modules\BoatSchedule\Database\Seeders;

use Illuminate\Database\Seeder;

class BoatScheduleDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
