<?php

namespace Modules\Partners\Database\Seeders;

use Illuminate\Database\Seeder;

class PartnersDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
