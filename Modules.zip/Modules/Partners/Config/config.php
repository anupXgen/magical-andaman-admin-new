<?php

return [
    'name' => 'Partners',
];
