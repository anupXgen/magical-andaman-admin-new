<?php

namespace Modules\Tourlocation\Database\Seeders;

use Illuminate\Database\Seeder;

class TourlocationDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
