<?php

namespace Modules\Packages\Database\Seeders;

use Illuminate\Database\Seeder;

class PackagesDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
