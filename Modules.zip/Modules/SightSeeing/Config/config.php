<?php

return [
    'name' => 'SightSeeing',
];
