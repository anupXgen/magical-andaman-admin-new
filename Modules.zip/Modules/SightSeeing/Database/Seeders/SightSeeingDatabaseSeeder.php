<?php

namespace Modules\SightSeeing\Database\Seeders;

use Illuminate\Database\Seeder;

class SightSeeingDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
