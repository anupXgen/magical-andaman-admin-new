<?php

namespace Modules\Package\Database\Seeders;

use Illuminate\Database\Seeder;

class PackageDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
