<?php

return [
    'name' => 'SightseeingLocation',
];
