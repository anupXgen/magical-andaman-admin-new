<?php

namespace Modules\SightseeingLocation\Database\Seeders;

use Illuminate\Database\Seeder;

class SightseeingLocationDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
