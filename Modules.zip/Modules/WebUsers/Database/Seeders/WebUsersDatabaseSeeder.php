<?php

namespace Modules\WebUsers\Database\Seeders;

use Illuminate\Database\Seeder;

class WebUsersDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
