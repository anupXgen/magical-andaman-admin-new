@extends('bookingrequest::layouts.master')

@section('content')
    <h1>Hello World</h1>

    <p>Module: {!! config('bookingrequest.name') !!}</p>
@endsection
