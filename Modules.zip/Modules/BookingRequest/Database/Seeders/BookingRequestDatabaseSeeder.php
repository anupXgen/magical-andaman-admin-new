<?php

namespace Modules\BookingRequest\Database\Seeders;

use Illuminate\Database\Seeder;

class BookingRequestDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
