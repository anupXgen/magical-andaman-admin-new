<?php

return [
    'name' => 'BookingRequest',
];
