<?php

return [
    'name' => 'Activity',
];
