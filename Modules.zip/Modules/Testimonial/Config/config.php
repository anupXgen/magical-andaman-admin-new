<?php

return [
    'name' => 'Testimonial',
];
