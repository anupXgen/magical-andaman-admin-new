<?php

namespace Modules\Cab\Database\Seeders;

use Illuminate\Database\Seeder;

class CabDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
