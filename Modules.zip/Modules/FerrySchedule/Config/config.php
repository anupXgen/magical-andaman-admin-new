<?php

return [
    'name' => 'FerrySchedule',
];
