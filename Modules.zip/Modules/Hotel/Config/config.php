<?php

return [
    'name' => 'Hotel',
];
