<?php

return [
    'name' => 'Destination',
];
