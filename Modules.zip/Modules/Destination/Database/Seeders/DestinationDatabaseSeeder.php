<?php

namespace Modules\Destination\Database\Seeders;

use Illuminate\Database\Seeder;

class DestinationDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
